/// <reference types="vite/client" />
    declare module './genieApi.js' {
        const genieApi: any; // Or more specific types if known
        export default genieApi;
    }